---
title: تاج لایف ۵۲ راز
emoji: 🃏
colorFrom: purple
colorTo: blue
sdk: docker
app_port: 7860
pinned: false
---

Live Crown 52: private control panel, public read-only screen, comment selections, server-timed five-second reveals and tiebreaks. App namespace: crown52-v1.
