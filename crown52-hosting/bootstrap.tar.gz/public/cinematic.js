/* Layered scene compositor: reference artwork, real portrait, lighting and particles. */
(()=>{
const themes=[
{id:'dragon',name:'اژدهای بنفش',color:'#c65dff',rgb:'193,69,255',position:'0%',cell:0,columns:3,atlas:'royal-atlas.png',open:1},
{id:'wings',name:'بال‌های آتش',color:'#ffbe53',rgb:'255,167,46',position:'50%',cell:1,columns:3,atlas:'royal-atlas.png',open:1},
{id:'lion',name:'شیر طلایی',color:'#ffd979',rgb:'255,192,65',position:'0%',cell:0,columns:3,atlas:'showcase-atlas.png',creature:2,open:0,video:'lion.webm'},
{id:'diamond',name:'الماس بلورین',color:'#b6f3ff',rgb:'168,231,255',position:'0%',cell:0,columns:2,atlas:'ice-diamond-atlas.png',cold:1,open:0,video:'diamond.webm'},
{id:'ice-dragon',name:'اژدهای یخی · حملهٔ کبرا',color:'#7ad9ff',rgb:'102,201,255',position:'50%',cell:1,columns:3,atlas:'showcase-atlas.png',cold:1,creature:1,open:0,video:'ice-dragon.webm'},
{id:'fire-dragon',name:'اژدهای آتشی · حملهٔ کبرا',color:'#ff973e',rgb:'255,114,32',position:'0%',cell:0,columns:3,atlas:'royal-atlas.png',open:0,video:'fire-dragon.webm'}
];
let choice=localStorage.getItem('crown-art-theme')||'auto',intensity=Number(localStorage.getItem('crown-fx-intensity'))||1;
if(choice==='dragon')choice='fire-dragon';
const controls=document.createElement('div');controls.className='cinema-controls';controls.innerHTML='<div class="divider"></div><label class="label" for="artTheme">انتخاب افکت</label><select class="field" id="artTheme"><option value="auto">ارتقای خودکار با کوین</option>'+themes.filter(t=>t.id!=='dragon').map(t=>`<option value="${t.id}">${t.name}</option>`).join('')+'</select><label class="label" for="fxIntensity" style="margin-top:14px">درخشندگی افکت</label><input id="fxIntensity" type="range" min="0.4" max="1.5" step="0.1" style="width:100%;accent-color:#e6bd75"><button class="btn" id="replayCinema">✦ اجرای دوبارهٔ افکت</button><p class="note">چهار افکت ویدیویی: شیر از غبار طلایی، الماس از خرده‌کریستال، اژدهای یخی با برف و مه سرد، اژدهای آتشی با شعله و شراره. عکس نمونه جدا از افکت باقی می‌ماند.</p>';
$('.controls').append(controls);$('#artTheme').value=choice;$('#fxIntensity').value=intensity;
$('#tiers').addEventListener('click',e=>{if(e.target.closest('[data-tier]')){choice='auto';$('#artTheme').value='auto';localStorage.setItem('crown-art-theme','auto');channel.postMessage({type:'artStyle',choice,intensity})}},true);
$('#artTheme').onchange=e=>{choice=e.target.value;localStorage.setItem('crown-art-theme',choice);render();channel.postMessage({type:'artStyle',choice,intensity})};$('#fxIntensity').oninput=e=>{intensity=Number(e.target.value);document.querySelectorAll('#hero video').forEach(v=>v.style.filter='brightness('+(.7+.3*intensity)+')');localStorage.setItem('crown-fx-intensity',intensity);channel.postMessage({type:'artStyle',choice,intensity})};
const sampleButton=document.createElement('button');sampleButton.className='btn';sampleButton.id='samplePortrait';sampleButton.textContent='نمایش با عکس نمونهٔ شما';$('.cinema-controls').append(sampleButton);
function showSample(){join({userId:'sample-viewer',name:'هوادار نمونه',avatar:location.origin+location.pathname.replace(/[^/]*$/,'')+'assets/showcase-atlas.png#sample'});const p=person();p.coins=1500;choice='auto';$('#artTheme').value='auto';channel.postMessage({type:'artStyle',choice,intensity});preview=null;render();}
sampleButton.onclick=showSample;
const previousMessage=channel.onmessage;channel.onmessage=e=>{if(e.data?.type==='artStyle'){choice=e.data.choice;intensity=Number(e.data.intensity)||1;$('#artTheme').value=choice;$('#fxIntensity').value=intensity;render()}else previousMessage?.(e)};
let disposeFluid=()=>{};
function mountFluidArt(container,design){
 const c=document.createElement('canvas');c.className='fluid-art';c.width=600;c.height=600;
 const gl=c.getContext('webgl',{alpha:true,premultipliedAlpha:false,antialias:false});if(!gl)return;
 const vertex=`attribute vec2 p;varying vec2 uv;void main(){uv=(p+1.)*.5;gl_Position=vec4(p,0.,1.);}`;
 const fragment=`precision mediump float;varying vec2 uv;uniform sampler2D art;uniform float time;uniform float theme;uniform float power;uniform float columns;uniform float cold;uniform float openSide;uniform float creature;uniform vec3 tint;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
 float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+9.7;a*=.5;}return v;}
 vec4 sampleArt(vec2 p){if(p.x<.008||p.x>.992||p.y<.005||p.y>.995)return vec4(0.);vec4 tex=texture2D(art,vec2((p.x+theme)/columns,1.-p.y));if(creature>.5&&creature<1.5){float breathArea=smoothstep(.62,.78,p.x)*(1.-smoothstep(.57,.66,p.y));tex.a*=1.-breathArea;}return tex;}
 void main(){float t=time;vec2 q=uv;vec2 flow=vec2(fbm(q*5.+vec2(t*.21,-t*.38)),fbm(q*6.+vec2(-t*.13,-t*.52)));
 float edge=smoothstep(.12,.45,abs(q.x-.5));float wind=(flow.x-.5)*(.055+.055*edge)*power*mix(1.,.55,cold);
 float roar=pow(max(0.,sin(t*1.45)),2.);
 vec2 motion=vec2(0.);
 if(creature>.5&&creature<1.5){
  float head=smoothstep(.42,.66,q.y)*(1.-smoothstep(.67,.80,q.x));
  float turn=sin(t*1.45)*.045*head;
  vec2 relative=q-vec2(.40,.61);
  motion+=vec2(-relative.y,relative.x)*turn;
  float jaw=(1.-smoothstep(.55,.66,q.y))*smoothstep(.39,.49,q.y)*smoothstep(.34,.47,q.x)*(1.-smoothstep(.71,.81,q.x));
  motion.y+=jaw*roar*.032;
 }else if(creature>1.5){float head=smoothstep(.35,.60,q.y)*(1.-smoothstep(.4,.6,q.x));motion.y+=head*sin(t*1.6)*.012;motion.x+=head*sin(t*.8)*.007;}
 vec2 displaced=q+vec2(wind,(flow.y-.5)*.035*power)+motion;vec4 base=sampleArt(displaced);
 // Advected, evaporating image trails: color and alpha are carried upward in the wind.
 vec4 plume=sampleArt(displaced+vec2((flow.y-.5)*.05,-.035-flow.x*.04));
 vec4 trail=sampleArt(displaced+vec2((flow.x-.5)*.09,-.075-flow.y*.05));
 float turbulence=fbm(q*14.+flow*3.+vec2(t*.2,-t*.95));
 float veil=smoothstep(.18,.72,turbulence);float a=base.a*(.27+.55*veil)+plume.a*.20*veil+trail.a*.13*veil;
 vec3 color=base.rgb*.77+plume.rgb*.16+trail.rgb*.07;
 vec3 ember=tint;
 float heat=max(0.,turbulence-.48)*1.7;
 color+=ember*heat*(base.a+plume.a*.4);
 float fade=smoothstep(0.,.05,q.x)*smoothstep(0.,.05,1.-q.x)*smoothstep(0.,.03,q.y)*smoothstep(0.,.03,1.-q.y);
 float opening=1.-openSide*smoothstep(.55,.78,q.x)*smoothstep(.22,.38,q.y);float alpha=clamp(a*fade*opening,0.,.94);

 gl_FragColor=vec4(color,alpha);}`;
 function compile(type,src){const sh=gl.createShader(type);gl.shaderSource(sh,src);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));return sh}
 let raf=0,stopped=false;const start=performance.now();try{const program=gl.createProgram(),vs=compile(gl.VERTEX_SHADER,vertex),fs=compile(gl.FRAGMENT_SHADER,fragment);gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('shader link');gl.useProgram(program);
 const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);const loc=gl.getAttribLocation(program,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
 const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 const time=gl.getUniformLocation(program,'time'),power=gl.getUniformLocation(program,'power');gl.uniform1f(gl.getUniformLocation(program,'theme'),design.cell);gl.uniform1f(gl.getUniformLocation(program,'columns'),design.columns);gl.uniform1f(gl.getUniformLocation(program,'cold'),design.cold||0);gl.uniform1f(gl.getUniformLocation(program,'openSide'),design.open);gl.uniform1f(gl.getUniformLocation(program,'creature'),design.creature||0);gl.uniform3fv(gl.getUniformLocation(program,'tint'),design.rgb.split(',').map(v=>Number(v)/255));gl.uniform1i(gl.getUniformLocation(program,'art'),0);
 const img=new Image();img.onload=()=>{if(stopped)return;gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);container.append(c);container.classList.add('fluid-ready');let lastFrame=0;function tick(now){if(stopped)return;raf=requestAnimationFrame(tick);if(document.hidden||now-lastFrame<32)return;lastFrame=now;gl.uniform1f(time,matchMedia('(prefers-reduced-motion: reduce)').matches?0:(now-start)/1000);gl.uniform1f(power,intensity);gl.drawArrays(gl.TRIANGLES,0,6)}raf=requestAnimationFrame(tick)};img.src='assets/'+design.atlas;
 disposeFluid=()=>{stopped=true;cancelAnimationFrame(raf);img.onload=null;gl.deleteTexture(tex);gl.deleteBuffer(buffer);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);gl.getExtension('WEBGL_lose_context')?.loseContext()};
 }catch(e){console.warn('Fluid rendering unavailable',e.message);container.setAttribute('aria-label',container.getAttribute('aria-label')+' — نمایش تصویر جایگزین')}
}
const originalRender=render;let theme=themes[0],burst=performance.now(),lastSignature='';
render=function(){disposeFluid();originalRender();const p=person(),idx=preview??tiers.reduce((n,t,i)=>p.coins>=t.n?i:n,-1);theme=themes.find(t=>t.id===choice)||themes[idx===6?4:idx===5?3:idx>=7?5:idx>=4?2:1];
 const h=$('#hero');if(p.avatar?.endsWith('#sample')){const av=h.querySelector('.avatar');av.replaceChildren();av.classList.add('sample-portrait');av.setAttribute('role','img');av.setAttribute('aria-label','عکس نمونه برگرفته از تصویر ارسالی');}h.classList.add('cinematic');h.dataset.theme=theme.id;h.style.setProperty('--accent',theme.color);h.style.setProperty('--art-x',theme.position);h.style.setProperty('--art-size',(theme.columns*100)+'% 100%');h.style.setProperty('--art-url',`url('assets/${theme.atlas}')`);
 const art=document.createElement('div');art.className='reference-art';art.dataset.open=theme.open;art.setAttribute('aria-label',theme.name);art.setAttribute('role','img');h.append(art);
 if(theme.video){
 art.classList.add('video-design');const clip=document.createElement('video');clip.className='dragon-clip';clip.src='assets/'+theme.video+'?v=wan-particles-1';clip.autoplay=true;clip.loop=true;clip.muted=true;clip.playsInline=true;clip.preload='auto';clip.style.filter='brightness('+(.7+.3*intensity)+')';clip.setAttribute('aria-label',theme.name+'؛ ویدیوی تشکیل از ذرات');art.append(clip);clip.play()?.catch(()=>{});disposeFluid=()=>{clip.pause();clip.removeAttribute('src');clip.load()};
 }else mountFluidArt(art,theme);
 h.querySelector('.creature')?.remove();h.querySelector('.crown')?.remove();h.querySelector('.aura-particles')?.remove();
 const label=h.querySelector('.tier-label');label.textContent='✦ '+theme.name+' ✦';
 const sig=p.id+':'+idx+':'+theme.id;if(sig!==lastSignature){lastSignature=sig;burst=performance.now();h.classList.add('cinema-enter')}
};
$('#replayCinema').onclick=()=>{const clip=$('#hero video');if(clip){clip.currentTime=0;clip.play()?.catch(()=>{})}burst=performance.now();const h=$('#hero');h.classList.remove('cinema-enter');void h.offsetWidth;h.classList.add('cinema-enter')};
const canvas=document.createElement('canvas');canvas.className='cinematic-canvas';canvas.setAttribute('aria-hidden','true');$('#stage').append(canvas);const ctx=canvas.getContext('2d');
let w=0,h=0,frame=0,last=0;const particles=Array.from({length:100},(_,i)=>({phase:Math.random()*Math.PI*2,r:95+Math.random()*80,speed:.15+Math.random()*.5,size:.6+Math.random()*2,seed:Math.random()*100}));
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
function resize(){const r=canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);w=r.width;h=r.height;canvas.width=w*d;canvas.height=h*d;ctx?.setTransform(d,0,0,d,0,0)}new ResizeObserver(resize).observe(canvas);
function draw(now){requestAnimationFrame(draw);if(!ctx||document.hidden||now-last<(reduce?200:30))return;last=now;frame++;ctx.clearRect(0,0,w,h);if(theme.video)return;const hero=$('#hero'),r=hero.getBoundingClientRect(),s=canvas.getBoundingClientRect(),x=r.left-s.left+r.width*.5,y=r.top-s.top+r.height*.41,scale=r.width/300,t=now/1000;ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.globalCompositeOperation='lighter';
 // Volumetric wisps follow the outside of the frame; multiple soft lobes give depth.
 for(let i=0;i<15*intensity;i++){const life=(t*.14+i*.067)%1,side=i%2?1:-1,px=side*(109+18*Math.sin(t*.6+i))+Math.sin(t*.7+i)*15,py=157-life*330;const g=ctx.createRadialGradient(px,py,1,px,py,theme.cold?44:36);g.addColorStop(0,`rgba(${theme.rgb},.12)`);g.addColorStop(.5,`rgba(${theme.rgb},.045)`);g.addColorStop(1,`rgba(${theme.rgb},0)`);ctx.fillStyle=g;ctx.fillRect(px-36,py-36,72,72)}
 for(let i=0;i<particles.length*intensity/1.5;i++){const p=particles[i],life=((t*.24+p.seed)%1),side=i%2?1:-1,px=side*(108+Math.sin(p.seed)*40)+Math.sin(t+p.seed)*16+life*12,py=170-life*350;ctx.globalAlpha=Math.sin(life*Math.PI)*.8;ctx.fillStyle=theme.color;ctx.shadowColor=theme.color;ctx.shadowBlur=8;ctx.beginPath();if(theme.cold){ctx.moveTo(px,py-p.size*2);ctx.lineTo(px+p.size,py);ctx.lineTo(px,py+p.size*2);ctx.lineTo(px-p.size,py);ctx.closePath()}else ctx.arc(px,py,p.size,0,Math.PI*2);ctx.fill();if(i%9===0){ctx.fillRect(px-5,py-.5,10,1);ctx.fillRect(px-.5,py-5,1,10)}}ctx.globalAlpha=1;ctx.shadowBlur=10;ctx.strokeStyle=theme.color;ctx.lineWidth=.7;
 
 const age=(now-burst)/1000;if(age<1.5&&!reduce){ctx.globalAlpha=Math.max(0,1-age/1.5);ctx.lineWidth=2;if(age<.25){ctx.globalAlpha=(.25-age)*1.8;const glow=ctx.createRadialGradient(0,0,0,0,0,210);glow.addColorStop(0,theme.color);glow.addColorStop(1,'transparent');ctx.fillStyle=glow;ctx.fillRect(-210,-210,420,420)}}ctx.restore();}
if(person().id==='demo'&&!person().avatar){person().coins=1500;preview=null;choice='auto';$('#artTheme').value='auto';person().avatar=location.origin+location.pathname.replace(/[^/]*$/,'')+'assets/showcase-atlas.png#sample';}
render();requestAnimationFrame(draw);
})();
